# Overview

DZ Control is a comprehensive production management system for a poultry processing facility. The application manages daily production planning, order management, inventory tracking, staff scheduling, and material calculations. It's built as a single-page application using vanilla TypeScript with Vite, focusing on real-time production tracking and resource optimization.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**Technology Stack:**
- Vanilla TypeScript with Vite build system
- No frontend framework - direct DOM manipulation
- TailwindCSS for styling via CDN
- Feather Icons for UI iconography
- Chart.js with datalabels plugin for data visualization
- jsPDF with AutoTable for PDF report generation

**Application Structure:**
- Entry point: `index.tsx` - Loads modals and initializes the application
- Main controller: `js/main.ts` - Handles view rendering and navigation
- Event handling: `js/eventHandler.ts` - Global event delegation system
- State management: `js/state.ts` - Centralized application state with localStorage persistence
- UI utilities: `js/ui.ts` - DOM element references and UI helper functions

**View System:**
- Views are loaded as HTML fragments from `public/views/` directory
- Dynamic content rendered via component-specific TypeScript modules in `js/components/`
- Modal dialogs loaded from multiple `views/modals_*.html` files on initialization
- Navigation managed through data attributes and view identifiers

**Component Organization:**
- Production components: daily planning, orders, calendar, KFC production, frozen products
- Settings components: products, mixes, customers, box weights, line settings
- Service modules: calculations, production logic, access control
- Utility modules: date handling, ID generation, time conversions

## Data Storage Solutions

**Client-Side Storage:**
- LocalStorage as primary data persistence layer
- Data key: `surovinyAppData_v13` (versioned schema)
- Auto-save functionality with dirty state tracking
- Manual save/load to file system for backup/restore
- State includes: products, orders, inventory, schedules, settings

**Data Structure:**
- Suroviny (raw materials) with properties: stock levels, weights, active status
- Products with marinades, loss percentages, calibration data
- Mix definitions with component percentages
- Orders organized by customer and date
- Box/tray type definitions and assignments
- Calendar events and planned actions
- Employee schedules and shift management
- KFC-specific products and inventory
- Frozen product production tracking

**State Management Patterns:**
- Single source of truth in `appState` object
- Immutable updates trigger save operations
- Dirty flag prevents unnecessary saves
- Auto-save notification system for user feedback

## External Dependencies

**CDN-Loaded Libraries:**
- TailwindCSS (styling framework)
- Chart.js (data visualization)
- chartjs-plugin-datalabels (chart annotations)
- jsPDF (PDF generation)
- jsPDF-AutoTable (table formatting in PDFs)
- Feather Icons (icon library)
- Google Fonts - Inter font family

**API Integration:**
- Gemini API integration configured via environment variables
- API key stored in `.env.local` file
- Environment variable access through Vite's define configuration
- Keys: `GEMINI_API_KEY`, exposed as `process.env.GEMINI_API_KEY` and `process.env.API_KEY`

**Development Tools:**
- Vite 6.2.0 (build tool and dev server)
- TypeScript 5.8.2 (type checking and compilation)
- Node.js type definitions for development

**Server Configuration:**
- Dev server on port 5000
- Host: 0.0.0.0 (accessible externally)
- HMR disabled
- Module resolution: bundler mode with path aliases (`@/*`)

**Build System:**
- ES2022 target with ESNext modules
- React JSX transformation (though not using React framework)
- Experimental decorators enabled
- Isolated modules for faster compilation
- TypeScript imports allowed without emission